conf:{
	name: 名称 必填,
	str: 数据 必填
}