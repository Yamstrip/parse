"use strict";
//错误字符获取
module .exports = function ( str , I , obj , lib ) {
	let ni = lib .ignoreI ( str , I , lib )
	let way = [ ]
	let card = [ ]
	for ( let j in obj .data ) {
		let d = obj .data [ j ]
		if ( str .substr ( ni , d .length ) !== d ) {
			//获取text
			let c = lib .ignore ( str .substr ( ni , d .length ) , obj )
			card .push ( {
				index: ni - I,
				data: c
			} )
			way .push ( `The structure '${c}' is changed to '${d}'` )
		}
	}
	//end
	return {
		text: card,
		error: way .join ( `\nor\n` )
	}
}