"use strict";
module .exports = function ( str ) {
	let line = { }
	let ind = 0
	line .index = { }
	str = str .split ( `\n` )
	for ( let i = 0; i < str .length; i ++ ) {
		line [ i +1 ] = {
			str: ind,
			end: str [ i ] .length + ind
		}
		for ( let j = line [ i + 1 ] .str; j <= line [ i + 1 ] .end; j ++ ) {
			line .index [ j ] = i + 1
		}
		ind += str [ i ] .length +1
	}
	line .data = str
	return line
}