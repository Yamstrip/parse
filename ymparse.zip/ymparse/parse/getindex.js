//index
module .exports = function ( I , d ) {
	let line = d .index [ I ]
	if ( typeof line === `number` ) {
		let s = d [ line ]
		if ( s ) {
			return I - s .str
		} else {
			return null
		}
	}
}