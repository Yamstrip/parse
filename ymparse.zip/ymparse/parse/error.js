"use strict";
module .exports = function ( conf ) {
	//name = 开始如 /../a.js
	//line = 行数组
	//lined = 行对象
	//text = 错误关键词
	/*[
		{
			text: ``,
			index: `` 必须大于该下标
		}
	]*/
	//error = 更改提示
	//show = 错误提示符号 如 ^ ~ -
	if ( conf .show == undefined || ! ( typeof conf .show === `string` ) ) {
		conf .show = `^`
	}
	conf .show = conf .show [ 0 ]
	let Eline = { }
	for ( let i = 0; i < conf .line .length; i ++ ) {
		let d = conf .lined .data [ conf .line [ i ] -1 ] + ``
		Eline [ conf .line [ i ] -1 ] = {
			data: d,
			error: [ ],
			line: conf .line [ i ]
		}
		//迭代
		for ( let j in conf .text ) {
			let ds = conf .text [ j ]
			
			for ( let k = 0; k < d .length; k ++ ) {
				if ( d .substr ( k , ds .data .length ) == ds .data && k >= ds .index ) {
					//添加错误指示行
					Eline [ conf .line [ i ] -1 ] .error .push ( {
						str: k,
						end: k + ds .data .length
					} )
					break
				}
			}
		}
	}
	//生成行下面的标识
	let d = ``
	for ( let i in Eline ) {
		let p = Eline [ i ]
		let strl = Eline [ i ] .line
		let stri = 0
		for ( let j in p .error ) {
			stri = p .error [ j ] .str
			break
		}
		d += conf .name + `:` + strl + `:` + stri + `\n`
		let s = [ p .data + `\n` ]
		let ks = [ ]
		for ( let j = 0; j < p .data .length; j ++ ) {
			ks .push ( ` ` )
		}
		for ( let j in p .error ) {
			for ( let k = p .error [ j ] .str; k < p .error [ j ] .end; k ++ ) {
				ks [ k ] = conf .show
			}
		}
		d += s .concat ( ks ) .join ( `` ) + `\n`
	}
	//结束语
	d += conf .error + `\n`
	return d
}
/*
let ds = module .exports ( {
	line: [ 2 ],
	lined: {
		data: [
			"var a = 3;",
			"let ---b @4 = 6;"
		]
	},
	name: `/storage/a/b/test.js`,
	text: [
		{
			index: 1,
			data: `---b`
		}
	],
	error: `\
SyntaxError: Unexpected token "---b"
	at Main.load.js:32:7
	at Main.fx.js:5:1
`
} )
console.log(ds)
*/