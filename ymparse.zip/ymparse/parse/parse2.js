"use strict";
module .exports = function ( conf , lib , push , nc ) {
	//定义一个连续结构
	let s = { }
	//定义 S 的 导出数据
	s .index = { }
	// S 的 语法树退出标志
	s .break = false
	// S 的 语法树名称
	s .ast = [ ]
	// S 的 data
	s .data = [ ]
	// S I
	s .i = conf .i
	//breakdata
	s .breakdata = null
	
	///语法树必须是连续的.append.或者.pipe.才可以继续连接，否则将视为解析数据传入conf
	///push是一个AST结构,负责专门储存
	//大循环
	
	//nc对象
	
	if ( nc ) {
		//I
		if ( nc .i ) {
			s .i = nc .i
		}
		//break Code
		if ( nc .break ) {
			s .breakdata = nc .break
		}
		//Father NC
		if ( nc .father ) {
			s .father = nc .father
		}
		//FatherNext
		if ( nc .fatherNext ) {
			s .fatherNext = nc .fatherNext
		}
	}
	
	while ( s .break == false ) {
		//定义结构
		let w = { }
		//定义val,vald
		w .val = { }
		w .vald = { }
		//suc成功值
		w .suc = false
		//定义new模式
		w .new = false
		
		//循环结构
		for ( let i in lib .lib ) {
			//定义当前
			let now = lib .lib [ i ]
			//定义可执行
			let accept = true
			//获取lib .lib i 的 结构
			let structure = lib .lib [ i ]
			//获取S的AST名称结构
			let ast = s .ast [ s .ast .length -1 ]
			//获取层次树
			let layer = conf .layer [ conf .layer .length -1 ]
			//OLDAPPENDACCEPT
			let acceptobj = true
			//Layer检测
			if ( layer !== undefined ) {
				if ( conf .layer .length !== 1 ) {
					let ts = lib .codetype [ layer ]
					//console.log(lib.codetype)
					if ( ts ) {
						if ( ts .child !== undefined && ts .childmust == true ) {
							if ( ts . child .indexOf ( now .name ) == -1 ) {
								acceptobj = false
							}
						}
					} else {
						acceptobj = false
					}
					if ( now .father ) {
						//console.log([now. father,layer,ast])
						if ( now .father .indexOf ( layer ) == -1 ) {
							acceptobj = false
						}
					}
				}
			} else {
				//层次树 不存在 , 默认 false
				acceptobj = false
			}
			//IF检测
			if ( ast !== undefined ) {
				//console.log(s)
				//这里有旧的结构,检测其appene,pipe连续性
				let oldobj = lib .lib [ ast ]
				//是否PIPE符合
				if ( oldobj .pipe !== undefined && oldobj .pipemust == true ) {
					if ( oldobj .pipe .indexOf ( now .name ) == -1 ) {
						acceptobj = false
						accept = false
					}
				} else {
					accept = false
				}
				//是否APPEND符合
				if ( now .append !== undefined && now .appendmust == true ) {
					if ( now .append .indexOf ( oldobj .name ) == -1 ) {
						acceptobj = false
						accept = false
					}
				} else {
					accept = false
				}
			} else {
				//特殊情况开头accept
				if ( now .append !== undefined && now .appendmust == true ) {
					//检测undefined
					if ( now .append .indexOf ( `undefined` ) == -1 ) {
						acceptobj = false
					}
				}
			}
			//传递s
			//可以检测val了
			//console.log(acceptobj,now.name,ast,accept)
			//console.log([`ast`,acceptobj,now.name,s.i,ast])
			if ( acceptobj == true ) {
				//显然通过accept
				conf .info [ now .name ] .accept += 1
				w .val = lib .parse3 ( conf , lib , now , s )
				console.log(
					w.val,
					(function(){
						if(w.val.type==`error`){
							return conf.reterror(w.val.error)
						}
					}())
				)
				if ( w .val .type == `successful` ) {
					//新语法树
					//console.log([`suc`,now.name,w.val,s.i])
					if ( accept == false ) {
						w .new = true
					}
					w .suc = true
					w .vald = now
					//结构体执行成功
					conf .info [ now .name ] .suc += 1
					break
				} else {
					//console.log(w.val,now.name,conf.reterror(w.val.error))
					conf .info [ now .name ] .err += 1
				}
			} else {
				//被拒绝的结构体次数
				conf .info [ now .name ] .refuse += 1
			}
		}
		if ( w .suc == true ) {
			//console.log(s.i,w.val,conf.str.length)
			//加减乘除下标
			if ( w .val .i ) {
				s .i = w .val .i
			}
			//添加
			let f = function ( ) {
				//ast
				s .ast .push ( w .vald .name )
				//console.log(`push成功,`,w.vald.name)
				//data
				if ( w .val .data ) {
					for ( let i in w .val .data ) {
						s .data .push ( w .val .data [ i ] )
					}
				}
			}
			//新data
			//封装
			let pack = {
				ast: s .ast,
				stack: lib .copy ( conf .stack ),
				data: s .data,
				index: s .index,
				father: conf .layer [ conf .layer .length -1 ],
				i: conf .i
			}
			//END
			if ( s .i >= conf .str .length -1 ) {
				push .push ( pack )
			}
			if ( w .new ) {
				//把以前的push到conf
				if ( s .data .length !== 0 ) {
					//数据push
					push .push ( pack )
				}
				//重置结构
				s .ast = [ ]
				s .data = [ ]
				s .index = { }
				f ( )
				//FX检测
				if ( conf .fx ) {
					fx ( {
						type: `pack`,
						data: push [ push .length -1 ],
						now: w .val
					} )
				}
			} else {
				f ( )
				//这样就只是ast
				if ( conf .fx ) {
					fx ( {
						type: `ast`,
						data: pack,
						now: w .val
					} )
				}
			}
			//检测跳出语法树
			if ( w .val .break ) {
				s .break = true
				break
			}
			//最后跳出
			if ( s .i >= conf .str .length -1 ) {
				s .break = true
				break
			}
		} else {
			//console.log([`error`,w.val])
			//返回异常
			//console.log(w)
			conf .errorstruck .push ( w .val .error )
			//console.log(conf.errorstruck)
			return conf .reterror ( Math .min .apply ( null , conf .errorstruck ) )
		}
	}
	//console.log(`弹出break`,conf.stack.length,push,s.i,conf.stack.length)
	return {
		type: `successful`,
		data: push,
		i: s .i
	}
}