"use strict";
module .exports = function ( conf , lib , obj , s ) {
	//第三阶段 - 详细语法检测
	let w = { }
	//状态
	w .suc = true
	//index
	w .index = { }
	//data
	w .data = [ ]
	//val
	w .val = { }
	//type
	w .type = `successful`
	w .error = 1
	//console.log([`data`,obj])
	for ( let i in obj .data ) {
		//对象提取
		let d = obj .data [ i ]
		//confs
		//console.log([`itdata`,i,obj.data.length,d.name])
		let confs = { }
		let ni = conf .ignoreI ( s .i , d )
		//Break
		confs .i = ni
		//console.log([s.i,confs.i])
		let lasti = confs .i
		if ( d .type == `code` ) {
			//进入下一层AST
			conf .stack .push ( `at ${conf.layer.join(`.`)} (${ conf .name }:${ conf .getline ( s .i ) }:${ conf .getindex ( s .i ) })` )
			//如果有Next Obj 定义 s .next Obj = else 定义 当前
			if ( obj .data [ Number ( i ) + 1 ] !== undefined ) {
				confs .fatherNext = obj .data [ Number ( i ) + 1 ]
			} else {
				confs .fatherNext = d
			}
			conf .layer .push ( obj .id [ d .father ] )
			confs .break = lib .copy ( d .break )
			//console.log([`str`,conf.stack,conf.layer])
			let code = lib .parse2 ( conf , lib , [ ] , confs )
			conf .stack .pop ( )
			conf .layer .pop ( )
			//console.log([`end`,conf.stack,conf.layer])
			if ( code == null ) {
				return {
					type: `error`,
					error: conf .erri
				}
			}
			if ( code .type == `successful` ) {
				s .i = code .i
				w .val = code
				w .index [ d .name ] = w .val .data
				w .data .push ( {
					data: w .val .data,
					type: d .name
				} )
			} else {
				w .error = code .erri
				w .suc = false
				w .type = `error`
				break
			}
		} else {
			//附加数据
			w .val = lib .type [ d .type ] .data ( conf , d , confs )
			if ( w .val .test == false ) {
				//console.log(w.val,d.type)
				w .error = w .val .erri
				w .suc = false
				w .type = `error`
				//console.log([`error`,w.error])
				break
			} else {
				//"console.log([`p3`,w.val])
				//默认data处理
				//console.log(`str`,`"`+w.val.data+`"`,d)
				w .val .data = conf .ignore ( w .val .data , d )
				//console.log([w.val.data,s.i])
				//console.log(`end`,`"`+w.val.data+`"`)
				//s数据
				if ( ! ( typeof w .val .i === `number` ) ) {
					throw Error ( `type:${d.type}返回无i数据` )
				}
				s .i = w .val .i
				//index
				w .index [ d .name ] = w .val .data
				//remove不添加
				if ( ! d .remove ) w .data .push ( {
					data: w .val .data,
					type: d .name
				} )
				//检测break
				//console.log(conf.isbreak(lasti,s.breakdata),s.i,d.name,`"`+conf.str.substr(lasti,5)+`"`,s.breakdata,w.suc,i,obj.data.length,conf.stack.length)
				//console.log([`sub`,conf.str.substr(s.i,10)])
				if ( ( s .breakdata instanceof Array === true ) && i == ( obj .data .length -1 ) + `` ) {
					//console.log([`信息`,lasti,s.i,conf.str.substr(lasti,s.breakdata.length),conf.str.substr(s.i,s.breakdata.length)])
					//父亲节点的当前层-1,DATA,I+1的,对象作为break NI检测
					let ni = conf .ignoreI ( s .i , s .fatherNext )
					let tb = conf .isbreak ( ni , s .breakdata )
					if ( tb .test == true ) {
						w .break = true
						s .breakdata = null
						//console.log([`break`,s.i])
						break
					}
				}
			}
		}
	}
	if ( w .suc == false ) {
		//错误
		//console.log([`errorE`,w])
		return {
			error: w .error,
			type: `error`
		}
	}
	//suc
	return {
		type: `successful`,
		data: w .data,
		index: w .index,
		break: w .break,
		error: w .error
	}
}