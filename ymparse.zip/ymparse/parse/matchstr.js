module .exports = function ( s , I , d ) {
	for ( let i = 0; i < d .length; i ++ ) {
		if ( s [ I + i ] !== d [ i ] ) {
			return false
		}
	}
	return true
}