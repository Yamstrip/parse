//EXIT AST
module .exports = function ( str , I , c ) {
	let suc = false
	//BF匹配
	let data = ``
	for ( let i in c ) {
		let d = c [ i ]
		if ( str .substr ( I , d .length ) == d ) {
			suc = true
			data = d
			break
		}
	}
	return {
		test: suc,
		text: data,
		length: data
	}
}