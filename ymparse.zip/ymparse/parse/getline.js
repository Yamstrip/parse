"use strict";
module .exports = function ( ind , line ) {
	let d = line .index [ ind ]
	if ( d == undefined && d + `` !== `NaN` ) {
		return line .length +1
	} else {
		return d
	}
}