"use strict";
//行信息
const lineparse = require ( `./lineparse.js` )

//下标所在行
const getline = require ( `./getline.js` )

//下标
const getindex = require ( `./getindex.js` )

//ERROR对象
const makeerror = require ( `./error.js` )

//退出语法树
const isbreak = require ( `./isbreak.js` )

//错误字符获取
const gettext = require ( `./gettext.js` )

//matchstr 字符串匹配
const matchstr = require ( `./matchstr.js` )

//MAINPARSE
module .exports = function ( conf , lib , push ) {
	//信息
	conf .info = { }
	//error缓存
	conf .errlib = { }
	conf .erri = 0
	conf .errorstruck = [ ]
	conf .buffer = Buffer ( conf .str )
	//封装行信息
	conf .lineData = lineparse ( conf .str )
	//封装获取行
	conf .getline = function ( index ) {
		return getline ( index , conf .lineData )
	}
	//copy
	conf .copy = function ( e ) {
		return lib .copy ( e )
	}
	//获取Erroe
	conf .gettext = function ( i , obj ) {
		return gettext ( conf .str , i , obj , conf .autostructure )
	}
	//获取index
	conf .getindex = function ( index ) {
		return getindex ( index , conf .lineData )
	}
	//strmatch
	conf .matchstr = function ( i , d ) {
		return matchstr ( conf .str , i , d )
	}
	//添加error
	conf .mkerror = function ( ) {
		conf .erri += 1
		conf .errlib [ conf .erri ] = arguments
		return conf .erri
	}
	//执行errir
	conf .reterror = function ( i ) {
		if ( conf .errlib [ i ] ) {
			return conf .error .apply ( null , conf .errlib [ i ] )
		} else {
			return null
		}
	}
	//封装Error
	conf .error = function ( line , text , error ) {
		let texts = [ ]
		//Line行
		if ( ! ( line instanceof Array === true ) ) {
			line = [ line ]
		}
		//Text关键词
		if ( ! ( line instanceof Array === true ) ) {
			line = [ line ]
		}
		//设置Text
		for ( let i in text ) {
			if ( typeof text [ i ] === `string` ) {
				texts .push ( {
					index: 0,
					data: text [ i ]
				} )
			} else 
			if ( text [ i ] .data ) {
				if ( text [ i ] .index == undefined ) {
					text [ i ] .index = 0
				}
				texts .push ( {
					index: text [ i ] .index,
					data: text [ i ] .data
				} )
			}
		}
		let e = makeerror ( {
			line,
			error,
			text: texts,
			name: conf .name,
			lined: conf .lineData,
			show: `^`,
		} )
		return {
			type: `error`,
			line,
			text,
			error: e
		}
	}
	//ignore
	conf .ignore = function ( a , b ) {
		return conf .autostructure .ignore ( a , b )
	}
	//ignoreI
	conf .ignoreI = function ( a , b ) {
		return conf .autostructure .ignoreI ( conf .str , a , b )
	}
	//BREAK检测
	conf .isbreak = function ( index , value ) {
		return isbreak ( conf .str , index , value )
	}
	//初始化
	//stack调用堆
	conf .stack = [ ]
	//ast层次树
	conf .layer = [ ]
	let confs = {
		stack: `at YmParse-Literal-translator (` + module .filename + `)`,
		father: `root`
	}
	conf .stack .push ( confs .stack )
	conf .layer .push ( `root` )
	//下标
	conf .i = 0
	//定义info
	conf .info = { }
	for ( let i in lib .lib ) {
		conf .info [ lib .lib [ i ] .name ] = {
			err: 0,
			refuse: 0,
			accept: 0,
			suc: 0
		}
	}
	//END
	let end = lib .parse2 ( conf , lib , push , confs  )
	return {
		info: conf .info,
		data: end
	}
}