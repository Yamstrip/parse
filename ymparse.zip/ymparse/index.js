//结构分析器
! function ( n ) {
	//添加结构
	n .print = function ( ) {
		n .prints = true
		console.log(`print开启`)
	}
	n .prints = false
	n .lib = { }
	/**
	 * Parse structure 
	 *
	*/
	n .add = function ( d , nf , af ) {
		if ( d .name !== undefined ) {
			if ( ! n .lib [ d .name ] ) {
				if ( typeof nf === `function` ) {
					d .endfx = nf
				}
				if ( typeof af === `function` ) {
					n .appfx = af
				}
				//省略
				if ( ! d .or ) {
					console .log ( d )
					throw `or 不可或缺`
				}
				//code
				for ( let i in d .data ) {
					let p = d .data [ i ]
					if ( p .type == `code` ) {
						if ( p .break ) {
							if ( ! ( p .break instanceof Array === true ) ) {
								p .break = [ p .break ]
							}
						} else {
							console.log(d,p)
							throw `type=code的情况下请添加break截断字符`
						}
					}
				}
				if ( ! ( d .or instanceof Array === true ) ) {
					d .or = [ d .or ]
				}
				//append
				if ( d .append && ! ( d .or instanceof Array === true ) ) {
					d .append = [ d .append ]
				}
				n .lib [ d .name ] = d
			}
		} else {
			console.log(d)
			throw `name 不可或缺`
		}
	}
	//add alot of Parse structure
	n .adds = function ( d ) {
		if ( ! ( d instanceof Array === true ) ) {
			d = [ d ]
		}
		for ( let i in d ) {
			n .add ( d [ i ] )
		}
	}
	/**
	 * 解释项目
	 * {
	 * //名称
	 	name: `name`,
	 	data: [ ],
	 	//append支持项目
	 	append: [ ],
	 	//mustappend必须连接append
	 	mustappend: true / false,
	 	//是上一个Parse的app的function
	 	appfx,
	 	//当前Parse的function
	 	endfx
	 }
	 * 解释数据
	 * {
	 	type: string 字符串 +[break| number 数字,
	 	or: true | false 可省略,
	 	min: len,最小值或长度
	 	max: len,最大值或长度
	 }
	 * 
	 * */
	 //remove Parse structure
	n .remove = function ( name ) {
		if ( ! ( name instanceof Array === true ) ) {
			name = [ name ]
		}
		for ( let i in name ) {
			delete n .lib [ name [ i ] ]
		}
	}
	//语意解析
	n .parse = function ( str , call ) {
		let d = n .parse2 ( {
			line: 1,
			index: 0,
			I: 0,
			str,
			father: `parse`,
			chain: [ `meta:Parse` ]
		} , call )
		if ( n .prints ) console .log ( str )
		return d
	}
	//词法解析
	n .parse1 = function ( d , conf ) {
		//console.log(conf)
		let ret = {
			len: 0,
			line: conf .line,
			index: conf .index,
			data: [ ],
			Edata: { },
			//obj: d,
			test: true,
			//AST名称
			Object: ``,
			//pipe
			pipe: conf .pipe,
			//连接下一个pipe，需要 d.append=[...,`..`] 声明pipe许可名称
			append: d .append,
			//添加pipe
			addapp: function ( name ) {
				if ( d .append .indexOf ( name ) == -1 ) {
					d .append .push ( name )
				}
			},
			//删除pipe
			removeapp: function ( name ) {
				if ( d .append .indexOf ( name ) == -1 ) {
					d .append .push ( name )
				}
			},
			//拒绝pipe -
			disapp: function ( ) {
				d .append = [ ]
			},
			//获取last pipe
			getpipe: function ( ) {
				return ret .pipe
			},
			//获取data
			getdata: function ( ) {
				let ds = ret .data
				if ( ret .pipe ) {
					for ( let i in ret .pipe ) {
						ds .push ( ret .pipe [ i ] )
					}
				}
				return ds
			},
			//name
			name: d .name
		}
		
		/*
		-------------data 检测
		*/
		if ( d .data ) {
			let S = conf .I
			for ( let i in d .data ) {
				//层次树 - Code Layer
				if ( d .data [ i ] .type == `code` ) {
					conf .chain .push ( d .name + `:` + ret .Object )
					if ( n .prints ) {
						console .log ( [`Print>Line:${ret.line},Index:${ret.index},I:${S}进入语法树:${conf.chain[conf.chain.length-1]}`] )
						console .log ( conf .chain )
					}
					let now = conf .chain .length -1

					let code = n .parse2 ( {
						//数据
						str: conf .str,
						//行下标
						index: ret .index,
						//总下标
						I: S,
						//行
						line: ret .line,
						//父级对象
						father: d .name,
						//code截断对象*2
						break: d .data [ i ] .break,
						//子break已经运行
						strbreak: ret .strbreak,
						//语法树
						chain: conf .chain
					} , conf .call )
					//console.log([code,`呃呃`,ret])
					if ( code .test == true ) {
						ret .data .push ( code .data )
						ret .line = code .line
						ret .index = code .index
						S = code .I
						if ( d .data [ i ] .export ) {
							ret .Edata [ d .data [ i ] .export ] = code .Edata
						}
						if ( n .prints ) {
							console .log ( [`Print>Line:${ret.line},Index:${ret.index},I:${S}退出语法树:${conf.chain[conf.chain.length-1]}`] )
						}
						conf .chain .splice ( conf .chain .length -1 , 1 )
						if ( n .prints ) console .log ( conf .chain )
					} else {
						if ( n .prints ) {
							console .log ( [`语法树错误StrLine:${ret.line},EndLine:${code.line},I:${S},检测链:`] )
							console .log ( [ `all:` , conf .chain ] )
							console .log ( [ `error` , conf .chain .slice ( now , conf .chain .length ) , `str` , now , `end` , conf .chain .length -1 ] , code .error )
						}
					}
					continue
					//新+1层次"
				}
				let v = n .testor ( d .data [ i ] , {
					str: conf .str,
					I: S,
					or: d .or,
					line: ret .line,
					index: ret .index,
					break: conf .break
				} )
				//console.log(`数据:`,v,d.data[i])
				if ( v .type == false ) {
					//ERROR
					ret .test = false
					ret .error = v .error
					ret .errline = v .errline
					ret .errindex = v .errindex
					return ret
				} else 
				if ( v .breakdata !== undefined ) {
					ret .len = S - v .len - conf .I
					ret .breakdata = v .breakdata
					ret .index = v .index
					ret .line = v .line
					ret .I = S + v .len
					return ret
				} else
				{
					//AST名称
					if ( d .data [ i ] .Object == true ) {
						ret .Object = v .data
					}
					ret .index = v .index
					ret .line = v .line
					//console.log(v)
					//+len
					//console.log(v)
					//export,data
					if ( d .data [ i ] .export ) {
						ret .Edata [ d .data [ i ] .export ] = v .data
					}
					S += v .len
					ret .I = S
					//console.log(v,`嗯`)
					ret .data .push ( {
						class: v .class,
						data: v .data ,
						line: ret .line,
						index: ret .index,
						meta: d .name,
						father: conf .father
					} )
				}
			}
			//成功运行 Data Match
			ret .len = S - conf .I
		}
		/*
		-------------pipe
		*/
		
		/*
		-------------fx Now
		这个函数执行当前fx
		*/
		if ( d .fx ) {
			d .fx ( ret )
		}
		/*
		--------------return
		*/
		return ret
		
	}
	//语法解析
	n .parse2 = function ( conf , call ) {
		let p = new Object
		//行
		p .line = conf .line
		//下标
		p .index = conf .index
		//解析情况
		p .test = true
		//数据
		p .data = [ ]
		//export Data
		//这个data是管道对象
		p .I = 0
		//pipe
		p .pipe = null
		//append
		p .append = [ ]
		let str = conf .str
		//P
		for ( let I = conf .I; I < conf .str .length; I ++ ) {
			let val
			//update

			let D = p .data .length == 0 ? {
				data: [ ],
				pipe: [ ]
			} :
			p .data [ p .data .length -1 ]
			let is = false
			for ( let i in n .lib ) {
				
				//前缀检测
				if ( n .lib [ i ] .last ) {
					let s = true
					for ( let j in n .lib [ i ] .last ) {
						if ( D .pipe .indexOf ( n .lib [ i ] .last [ j ] ) == -1 ) {
							s = false
							break
						}
					}
					if ( s ) {
						continue
					}
				}
				
				val = n .parse1 ( n .copy ( n .lib [ i ]  ) , {
					//总下标
					I: n .copy ( I ),
					//行
					line: n .copy ( p .line ),
					//下标
					index: p .index,
					//管道
					pipe: D .pipe,
					//回调
					call,
					//数据
					str: conf .str,
					//父级对象
					father: conf .father,
					//code截断对象
					break: conf .break,
					//语法树列表
					chain: conf .chain
				} )
				
				//console.log(val)
				
				if ( ! val ) {
					continue
					
				}
				//console.log(val)
				//return
				//console.log(val,`s`)
				//console.log(n.lib[i],i,val.test)
				if ( val .test == true ) {
					//++--len
					AP = true
					is = true
					if ( n .lib [ i ] .fe ) {
						n .lib [ i ] .fe ( p )
					}
					break
				}
			}
			let dos = true
			if ( p .append .indexOf ( val .name ) == -1 ) {
				dos = false
			}
			//console.log(p.append,val.name)
			if ( dos == false ) {
				p .data .push ( {} )
			}
			p .append = val .append
			if ( ! p .append ) {
				p .append = [ ]
			}
			let index = p .data .length -1
			//管道值
			if ( ! p .data [ p .data .length -1 ] .data ) {
				p .data [ p .data .length -1 ] = {
					//数据
					data: [ ],
					//连接链
					pipe: [ ],
					//Edata
					Edata: { },
					//数据
					lib: { },
					//fx
					on: { },
					//函数库
					fx: {
						//错误
						error: function ( data , line , index ) {
							p .test = false
							p .error = data
							p .errline = line
							p .errindex = index
							return p
						},
						//ON
						on: function ( name , data ) {
							p .data [ index ] .on [ name ] = data
						},
						//EMIT
						emit: function ( name , data , call ) {
							if ( p .data [ index ] .on [ name ] ) {
								p .data [ index ] .on [ name ] ( data , call )
							} else {
								console.log(name,data)				
								yc .c ( `e` , `emit>[${name}]在下标[${index}]不存在` )
							}
						},
						//SET
						set: function ( name , data ) {
							p .data [ index ] .lib [ name ] = data
						},
						//GET
						get: function ( name ) {
							return p .data [ index ] .lib [ name ]
						}
					},
				index
				}
			}
			p .data [ p .data .length -1 ] .pipe .push ( val .name )
			//返回VAL
			for ( let k in val .data ) {
				p .data [ p .data .length -1 ] .data .push ( val .data [ k ] )
			}
			//edata
			for ( let k in val .Edata ) {
				p .data [ index ] .Edata [ k ] = val .Edata [ k ]
			}
			if ( val .line ) {
				p .line = val .line
			}
			if ( val .index ) {
				p .index = val .index
			}
			if ( val .test == false ) {
				//ERROR
				p .test = false
				//console.log(val)
				p .error = val .error
				p .errindex = val .errindex
				p .errline = val .errline
				return p
			} else 
			if ( val .breakdata ) {
				p .I = val .I -2
				console.log(val)
				//去掉空对象
				if ( p .data [ p .data .length -1 ] .data .length == 0 ) {
					p .data .splice ( p .data .length -1 , 1 )
				}
				return p
			} else
			{
				//Test Lib
				if ( val .I ) {
					I = val .I -1
					p .I = I
					//I --
				}
				
				//console.log(val.I,`r`)
				p .dataNow = val .data
				p .pipeNow = n .copy ( p .data [ index ] .pipe )
				p .data [ index ] .fx .line = val .line
				p .data [ index ] .fx .index = val .index
				//FX
				if ( call ) {
					call ( p , p .data [ index ] .fx )
				}
				//错误
				p .I = I
				if ( p .test == false ) {
					return p
				}
			}
		}
		return p
	}
	//切割
	n .substr = function ( str , s , index , max ) {
		let cat = false
		let ind = 0
		if ( ! ( s instanceof Array === true ) ) {
			s = [ s ]
		}
		for ( let i = index; i < str .length; i ++ ) {
			for ( let j in s ) {
				let d = s [ j ]
				if ( str .substr ( i , d .length ) == d ) {
					//截断
					cat = true
					ind = i
					break
				}
			}
			if ( cat ) {
				break
			}
		}
		//ret
		if ( ind - index > max ) {
			ind = max
		} else {
			ind = ind - index
		}
		return str .substr ( index , ind )
	}
	//检测数据*多
	n .testor = function ( d , conf ) {
		//console.log(conf)
		let f = true
		//匹配出的数据长度
		let len = 0
		let error = ``
		//index
		let index = conf .index
		let ni = 0
		let data = ``
		let line = conf .line
		let breakdata
		let errindex = 0
		let errline = 0
		//APPEND
		//去忽略
		//\n
		//console.log(conf)
		let next = false
		
		for ( let i = conf .I; i < conf .str .length; i ++ ) {
			let st = false
			let to = conf .or
			for ( let j in to ) {
				let h = to [ j ]
				if ( conf .str .substr ( i , h .length ) == h ) {
					st = true
					ni += h .length
					i += h .length -1
					break
				}
			}
			if ( ! st ) {
				break
			}
		}
		//\n忽略掉
		for ( let i = conf .I + ni ; i < conf .str .length; i ++ ) {
			if ( conf .str [ i ] == `\n` ) {
				line += 1
				ni += 1
				index = 0
			} else {
				break
			}
		}
		if ( conf .break ) {
			//conf层截断
			for ( let i in conf .break ) {
				let d = conf .break [ i ]
				if ( conf .str .substr ( conf .I + ni , d .length ) == d ) {
					len = ni + d .length +1
					data = d
					next = true
					breakdata = true
					if ( true ) console .log ( `Print>Line:${line},Index:${index},I:${conf.I},break了语法树By:${d}` )
					break
				}
			}
		}
		if ( next ) {
			
		} else
		//INT类型
		if ( d .type == `int` ) {
			let all = [ ]
			for ( let k = conf .I + ni ; k < conf .str .length; k ++ ) {
				let d = conf .str [ k ]
				if ( d <= 9 && d >= 0 ) {
					all .push ( d )
				} else {
					break
				}
			}
			if ( all .length == 0 ) {
				f = false
				error = `Syntax error > "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" type Error (INT type)`
				errline = line
				errindex = index
				if ( n .prints ) console .log ( `Print>Line:${line},Index:${index},I:${conf.I},,无法通过INT检测` )
			} else {
				len = all .length
				data = Number ( all .join ( `` ) )
				if ( n .prints ) console .log ( `Print>Line:${line},Index:${index},I:${conf.I},,INT导出了:${data}` )
			}
		} else
		//定值类型
		if ( d .type == `text` || ! d .type ) {
			data = ``
			if ( typeof d === `string` ) {
				data = d + ``
			} else {
				data = d .data + ``
			}
			//设置len长度
			if ( conf .str .substr ( conf .I + ni , data .length ) !== data ) {
				error = `Syntax error > "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" Change to "${data}"`
				errline = line
				errindex = index
				f = false
				if ( n .prints ) console .log ( `Print>Line:${line},Index:${index},I:${conf.I},,ErrText检测data:${conf .str .substr ( conf .I + ni , data .length )};goal:${data}` )
			} else {
				//设置len长度
				len = data .length
				if ( n .prints ) console .log ( `Print>Line:${line},Index:${index},I:${conf.I},,通过Text:${data}` )
			}
		} else
		//字符串类型
		if ( d .type == `string` ) {
			let st = true
			data = ``
			//BREAK
			if ( ! d .break ) {
				//console.log(d)
				throw `数据异常 >没有break数组终止下标`
			}
			//检测是否打断
			for ( let i = conf .I + ni; i < conf .str .length; i ++ ) {
				//console.log(conf.str[i],i,d.break)
				for ( let j = 0; j < d .break .length; j ++ ) {
					let p = d .break [ j ]
					if ( conf .str .substr ( i , p .length ) == p ) {
						st = false
						data = conf .str .substring ( conf .I + ni , i )
						//console.log(`str-`,data)
						break
					}
				}
				if ( ! st ) {
					break
				}
			}
			//len设置
			len = data .length
			if ( n .prints ) console .log ( `Print>Line:${line},Index:${index},String导出了[${data}],I:${conf.I},,Break:[${d.break}]` )
			//去省略
			if ( d .or ) {
				for ( let i in d .or ) {
					while ( data .indexOf ( d .or [ i ] ) !== -1 ) {
						data = data .replace ( d .or [ i ] , `` )
					}
				}
			}
			//最大
			if ( d .max ) {
				if ( data .length > d .max ) {
					len = 0
					f = false
					error = `Data error > "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" Length greater than ${d.max}`
					errline = line
					errindex = index
				}
			}
			//最小
			if ( d .min ) {
				if ( data .length < d .min ) {
					len = 0
					f = false
					error = `Data error > "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" Length less than ${d.min}`
					errline = line
					errindex = index
				}
			}
			//0不是数字
			if ( data [ 0 ] <= 9 && data [ 0 ] >= 0 ) {
				len = 0
				f = false
				error = `String Error> "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" You cannot start with a number`
				errline = line
				errindex = index
			}
			
			//包括
			if ( d .include ) {
				//必须包括里面的
				for ( let i in d .include ) {
					if ( data .indexOf ( d .include [ i ] ) == -1 ) {
						//错误
						len = 0
						f = false
						error = `Data error > "${ n .substr ( conf .str , conf .or , conf .I + ni , 20 ) }" Missing "${d.include[i]}"`
						errline = line
						errindex = index
						break
					}
				}
			}
			//字符串
			//console.log(data+`F`)
		}
		//数字类型
		
		//console.log(data+`w`)
		len += ni
		index += len
		return {
			type: f,
			len: len,
			error,
			index,
			line,
			ni,
			class: d .class,
			data,
			errline,
			errindex,
			breakdata
		}
	}
	n .copy = function ( target ) { 
		let copyed_objs = [  ]
		//此数组解决了循环引用和相同引用的问题，它存放已经递归到的目标对象 
		function _deepCopy(target){ 
			if ( ( typeof target !== 'object' ) || ! target ) { 
				return target;
			}
			for ( let i = 0 ; i < copyed_objs .length; i++ ) {
				if ( copyed_objs [ i ] .target === target ) {
					return copyed_objs [ i ] .copyTarget;
				}
			}
			let obj = { };
			if ( Array .isArray ( target ) ) {
				obj = [ ];//处理target是数组的情况 
			}
			copyed_objs .push ( {
				target: target,
				copyTarget: obj
			} ) 
			Object .keys ( target ) .forEach ( key => {
				if ( obj [ key ] ) {
					return
				} 
				obj [ key ] = _deepCopy ( target [ key ] )
			} ); 
			return obj;
		} 
		return _deepCopy ( target );
	}
	//lib
	n .abc = `abcdefghijklmnopqrstuvwxyz_#$@`
	n .abcs = { }
	//sum
	! function ( d ) {
		for ( let i in d ) {
			n .abcs [ d [ i ] ] = n .abcs [ d [ i ] .toUpperCase ( ) ] = true
		}
	} ( n .abc )
} ( exports )