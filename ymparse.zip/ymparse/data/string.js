"use strict";
module .exports = {
	name: `string`,
	//testType
	test: function ( d ) {
		if ( d .break == undefined ) {
			return {
				type: false,
				error: `结构:(${d.name}),type:(string):缺少break数据来终止提取字符串检测`
			}
		}
		//notstr str禁止包括
		if ( d .notstr !== undefined && ! ( d .notstr instanceof Array === true ) ) {
			d .notstr = [ d .notstr ]
		}
		//break数组化
		if ( d .break !== undefined && ! ( d .break instanceof Array === true ) ) {
			d .break = [ d .break ]
		}
		return {
			type: true
		}
	},
	data: function ( conf , obj , nc ) {
		//定义长度
		let len = 0
		//迭代
		let ind = conf .str .length -1
		//ids
		let ins = false
		//allis 全部都是break的字符 
		let allbreak = true
		for ( let i = nc .i; i < conf .str .length; i ++ ) {
			let state = false
			for ( let j in obj .break ) {
				let d = obj .break [ j ]
				if ( conf .matchstr ( i , d ) ) {
					state = true
					//弹出
					if ( ( allbreak == false && obj .getbreak == true ) || ( obj .getbreak !== true ) ) {
						ind = i
						ins = true
						break
					}
					i += d .length -1
					break
				}
			}
			if ( state == false && allbreak == true ) {
				allbreak = false
			}
			if ( ins ) {
				break
			}
		}
		//IF
		if ( obj .notstr !== undefined ) {
			let ds = conf .isbreak ( nc .i , obj .notstr )
			if ( ds .test == true ) {
				let line = conf .getline ( nc .i )
				let error = `SyntaxError: Unexpected token '${ds.text}'\n` + conf .copy ( conf .stack .join ( `\n` ) )
				let errori = conf .mkerror ( line , ds .text , error )
				return {
					test: false,
					erri: errori
				}
			}
		}
		return {
			data: conf .str .substring ( nc .i , ind ),
			i: ind,
			test: true
		}
	}
}