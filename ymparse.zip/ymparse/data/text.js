"use strict";
module .exports = {
	name: `text`,
	//testType
	test: function ( d ) {
		
		//break数组化
		if ( d .data == undefined ) {
			return {
				type: false,
				error: `结构:(${d.name}),type:(text):缺少下标data,来标识匹配字符`
			}
		}
		//数组化
		if ( ! ( d .data instanceof Array === true ) ) {
			d .data = [ d .data ]
		}
		//头快速检测
		d .headtest = d .data
		return {
			type: true
		}
	},
	data: function ( conf , obj , nc ) {
		//定义长度
		let suc = false
		let data = ``
		//console.log(obj.data,1)
		for ( let i in obj .data ) {
			let d = obj .data [ i ]
			//console.log(`[${conf.str.substr(nc .i,d.length)}],[${d}]`)
			if ( conf .str .substr ( nc .i , d .length ) == d ) {
				suc = true
				data = d
				break
			}
		}
		if ( suc == true ) {
			return {
				test: true,
				data,
				i: nc .i + data .length
			}
		} else {
			let line = conf .getline ( nc .i +1 )
			let ed = conf .gettext ( nc .i , obj )
			let error = `SyntaxError: invalid structure:\n` + ed .error + `\n` + conf .copy ( conf .stack ) .join ( `\n` )
			//console.log(ed,error)
			let errori = conf .mkerror ( line , ed .text , error )
			return {
				test: false,
				erri: errori
			}
		}
	}
}