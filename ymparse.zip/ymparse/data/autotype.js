"use strict";
module .exports = [
	require ( `./string.js` ),
	require ( `./text.js` )
]