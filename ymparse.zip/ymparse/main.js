"use strict";



//添加解析结构函数
const add = require ( `./lib/add.js` )
//添加数据结构
const addtype = require ( `./lib/addtype.js` )
//默认数据结构
const autotype = require ( `./data/autotype.js` )
//设置函数
const sets = require ( `./lib/set.js` )
//默认数据处理
const autostructure = require ( `./lib/autostructure.js` )



//MAIN
exports .lib = { }
exports .type = { }
exports .codetype = { }



//parse主函数1
exports .parse1 = require ( `./parse/parse1.js` )
//parse主函数2
exports .parse2 = require ( `./parse/parse2.js` )
//parse主函数3
exports .parse3 = require ( `./parse/parse3.js` )



//COPY
exports .copy = require ( `./lib/copy.js` )



//ADDTYPE
exports .addtype = function ( data ) {
	return addtype ( data , exports )
}
//EXPORTS
exports .add = function ( data ) {
	return add ( data , exports )
}
//Main Parse
exports .parse = function ( conf , call ) {
	if ( ! ( typeof conf .call === `function` ) ) {
		if ( typeof call === `function` ) {
			conf .call = call
		}
	}
	conf .father = `none`
	conf .autostructure = autostructure
	return exports .parse1 ( conf , exports , [ ] )
}



//AUTO TYPE
exports .addtype ( autotype )
//AUTO CONF