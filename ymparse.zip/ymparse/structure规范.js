sstructure规范

{
	name: 名称 必填,
	data: [
		{
			name: 结构数据名称 必填,
			type: 结构数据类型 必填,
			...
			其他参数依据各种type的API
			type: code 开启语法树 选填,
			如果type: code:
				id: 更新父节点id-对照名称,
				child: 限定子节点
				break: - 终结字符
			...
		}
		...
	] 必填,
	father: [ ... ] 限定语法树父节点名称.选填,
	conf: { xxx: xxx }.强行加到data[i]下标 选填,
	pipe: [ `名称` ...] 只允许后面出现的结构 选填,
	appebd: [ `名称` ...] 只允许前面出现的结构 选填
}