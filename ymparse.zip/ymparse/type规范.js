TYPE规范

{
	name: 名称 必填,
	data: function ( 对象(解析) , 结构 ) {
		对象 .str = 全局数据
		对象 .i = 当前解析下标
		对象 .break ?= 当前语法树截断
		对象 .line = 行数
		对象 .linestr = 该行开始下标
		对象 .lineend = 改行结束下标
		对象 .error = function ( d )
		d = {
			d .line = 行数
			d .error = 信息
			d .text = 错误字符或字符数组
		}
		结构 = ymparse .add 里面的结构
		返回数据:
		{
			i: 新下标,
			data: 数据,
			test: true 正确是否,
			break: true //是否跳出语法树
		}
	} 必填,
	test: function ( 数据 ) {
		//负责检测语法数据准确性
		return {
			type: true | false,
			data: ...
		}
		//返回true代表通过,false不通过，且data返回错误依据
	} 必填
}
